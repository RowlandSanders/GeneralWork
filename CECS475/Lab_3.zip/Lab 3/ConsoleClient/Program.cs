﻿using DomainModel;
using Mm.BusinessLayer;
using System;
using System.Collections.Generic;

namespace ConsoleClient
{
    class Program
    {
        private static IBusinessLayer bLayer = new BusinessLayer();

        static void Main(string[] args)
        {
            run();
        }

        /// <summary>
        /// Display the menu and get user selection until exit.
        /// </summary>
        public static void run()
        {
            bool repeatCondition = true;
            int usrInput;

            do
            {
                Menu.displayMenu();
                usrInput = Validator.getMenuInput();

                switch (usrInput)
                {
                    case 0:
                        repeatCondition = false;
                        break;
                    case 1:
                        Menu.clearMenu();
                        addTeacher();
                        break;
                    case 2:
                        Menu.clearMenu();
                        updateTeacher();
                        break;
                    case 3:
                        Menu.clearMenu();
                        removeTeacher();
                        break;
                    case 4:
                        Menu.clearMenu();
                        listTeachers();
                        break;
                    case 5:
                        Menu.clearMenu();
                        listTeacherCourses();
                        break;
                    case 6:
                        Menu.clearMenu();
                        addCourse();
                        break;
                    case 7:
                        Menu.clearMenu();
                        updateCourse();
                        break;
                    case 8:
                        Menu.clearMenu();
                        removeCourse();
                        break;
                    case 9:
                        Menu.clearMenu();
                        listCourses();
                        break;
                    case 10:
                        Menu.clearMenu();
                        reassignCourse();
                        break;
                }
            } while (repeatCondition);
        }

        //CRUD for teachers

        /// <summary>
        /// Add a teacher to the database.
        /// </summary>
        public static void addTeacher()
        {
            Console.WriteLine("Enter a teacher name: ");
            string tName = Console.ReadLine();
            Teacher t = new Teacher() { TeacherName = tName };
            t.EntityState = EntityState.Added;
            bLayer.AddTeacher(t);
            Console.WriteLine("{0} has been added to the database.", tName);
        }

        /// <summary>
        /// Update the name of a teacher.
        /// </summary>
        public static void updateTeacher()
        {
            Menu.displaySearchOptions();
            int usrInput = Validator.getOptionInput();
            listTeachers();

            //Find by a teacher's name
            if (usrInput == 1)
            {
                Console.WriteLine("Enter a teacher's name: ");
                Teacher t = bLayer.GetTeacherByName(Console.ReadLine());
                if (t != null)
                {
                    Console.WriteLine("Change this teacher's name to: ");
                    t.TeacherName = Console.ReadLine();
                    t.EntityState = EntityState.Modified;
                    bLayer.UpdateTeacher(t);
                }
                else
                {
                    Console.WriteLine("Teacher does not exist.");
                };
            }
            //find by a teacher's id
            else if (usrInput == 2)
            {
                int id = Validator.getId();
                Teacher t = bLayer.GetTeacherById(id);
                if (t != null)
                {
                    Console.WriteLine("Change this teacher's name to: ");
                    t.TeacherName = Console.ReadLine();
                    t.EntityState = EntityState.Modified;
                    bLayer.UpdateTeacher(t);
                }
                else
                {
                    Console.WriteLine("Teacher does not exist.");
                };
            }
        }

        /// <summary>
        /// Remove a teacher from the database.
        /// </summary>
        public static void removeTeacher()
        {
            listTeachers();
            int id = Validator.getId();
            Teacher t = bLayer.GetTeacherById(id);
            if (t != null)
            {
                Console.WriteLine("{0} has been removed.", t.TeacherName);
                t.EntityState = EntityState.Deleted;
                bLayer.RemoveTeacher(t);
            }
            else
            {
                Console.WriteLine("Teacher does not exist.");
            };
        }

        /// <summary>
        /// List all teachers in the database.
        /// </summary>
        public static void listTeachers()
        {
            IList<Teacher> tList = bLayer.GetAllTeachers();
            foreach (Teacher t in tList)
                Console.WriteLine("Teacher ID: {0}, Name: {1}", t.TeacherId, t.TeacherName);
        }

        /// <summary>
        /// List the courses of a specified teacher.
        /// </summary>
        public static void listTeacherCourses()
        {
            listTeachers();
            int id = Validator.getId();
            Teacher t = bLayer.GetTeacherById(id);
            if (t != null)
            {
                Console.WriteLine("Listing courses for [ID: {0}, Name: {1}]:", t.TeacherId, t.TeacherName);
                if (t.Courses.Count > 0)
                {
                    foreach (Course course in t.Courses)
                        Console.WriteLine("Course ID: {0}, Name: {1}", course.CourseId, course.CourseName);
                }
                else
                {
                    Console.WriteLine("No courses for [ID: {0}, Name: {1}]:", t.TeacherId, t.TeacherName);
                };

            }
            else
            {
                Console.WriteLine("Teacher does not exist.");
            };
        }

        //CRUD for courses

        /// <summary>
        /// Add a course to a teacher.
        /// </summary>
        public static void addCourse()
        {
            Console.WriteLine("Enter a course name: ");
            string cName = Console.ReadLine();

            listTeachers();
            Console.WriteLine("Select a teacher for this course. ");
            int id = Validator.getId();
            Teacher t = bLayer.GetTeacherById(id);

            if (t != null)
            {
                //create course
                Course course = new Course()
                {
                    CourseName = cName,
                    TeacherId = t.TeacherId,
                    EntityState = EntityState.Added
                };

                //add course to teacher
                t.EntityState = EntityState.Modified;
                foreach (Course c in t.Courses)
                    c.EntityState = EntityState.Unchanged;
                t.Courses.Add(course);
                bLayer.UpdateTeacher(t);
                Console.WriteLine("{0} has been added to the database.", cName);
            }
            else
            {
                Console.WriteLine("Teacher does not exist.");
            };
        }

        /// <summary>
        /// Update the name of a course.
        /// </summary>
        public static void updateCourse()
        {
            Menu.displaySearchOptions();
            int usrInput = Validator.getOptionInput();
            listCourses();

            //find course by name
            if (usrInput == 1)
            {
                Console.WriteLine("Enter a course's name: ");
                Course c = bLayer.GetCourseByName(Console.ReadLine());
                if (c != null)
                {
                    Console.WriteLine("Change this course's name to: ");
                    c.CourseName = Console.ReadLine();
                    c.EntityState = EntityState.Modified;
                    bLayer.UpdateCourse(c);
                }
                else
                {
                    Console.WriteLine("Course does not exist.");
                };
            }
            //find course by id
            else if (usrInput == 2)
            {
                int id = Validator.getId();
                Course c = bLayer.GetCourseById(id);
                if (c != null)
                {
                    Console.WriteLine("Change this course's name to: ");
                    c.CourseName = Console.ReadLine();
                    c.EntityState = EntityState.Modified;
                    bLayer.UpdateCourse(c);
                }
                else
                {
                    Console.WriteLine("Course does not exist.");
                };
            }
        }

        /// <summary>
        /// Reassign course from one teacher to the other
        /// </summary>
        public static void reassignCourse()
        {
            Menu.displaySearchOptions();
            int usrInput = Validator.getOptionInput();

            if (usrInput == 1)
            {
                listCourses();
                Console.WriteLine("Enter a course's name: ");
                Course c = bLayer.GetCourseByName(Console.ReadLine());
                if (c != null)
                {
                    listTeachers();
                    Console.WriteLine("Choose the teacher you would like to reassign to this course: ");
                    int id = Validator.getId();
                    Teacher t = bLayer.GetTeacherById(id);
                    c.TeacherId = t.TeacherId;
                    c.Teacher = t;
                }
            }
            else if (usrInput == 2)
            {
                listCourses();
                Console.WriteLine("Enter the course's ID: ");
                int cid = Validator.getId();
                Course c = bLayer.GetCourseById(cid);

                if (c != null)
                {
                    listTeachers();
                    Console.WriteLine("Choose the teacher you would like to reassign to this course: ");
                    int id = Validator.getId();
                    Teacher t = bLayer.GetTeacherById(id);
                    Teacher ogT = c.Teacher;

                    ogT.Courses.Remove(c);
                    ogT.EntityState = EntityState.Modified;
                    bLayer.UpdateTeacher(ogT);

                    c.Teacher = t;
                    c.EntityState = EntityState.Modified;
                    bLayer.UpdateCourse(c);
                }
            }
       
        }

        /// <summary>
        /// Remove a course in the database.
        /// </summary>
        public static void removeCourse()
        {
            listCourses();
            int id = Validator.getId();
            Course c = bLayer.GetCourseById(id);
            if (c != null)
            {
                Console.WriteLine("{0} has been removed.", c.CourseName);
                c.EntityState = EntityState.Deleted;
                bLayer.RemoveCourse(c);
            }
            else
            {
                Console.WriteLine("Course does not exist.");
            };
        }

        /// <summary>
        /// List all courses in the database.
        /// </summary>
        public static void listCourses()
        {
            IList<Course> cList = bLayer.GetAllCourses();
            foreach (Course c in cList)
                Console.WriteLine("Course ID: {0}, Name: {1}", c.CourseId, c.CourseName);
        }
    }
}